<header class="p-0 m-0">
    <section class="container" style="height: 10vh">
        <div class="row">
            <div class="col-lg-10">Компания-тема</div>
            <div class="col-lg-2">+7 963 272 72 82</div>
        </div>
    </section>
</header>
