<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <META NAME="description">
        <title>Мебель на заказ</title>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo/logo.png')); ?>"/>
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href=<?php echo e(asset('css/owl.carousel.min.css')); ?>>
        <link rel="stylesheet" href=<?php echo e(asset('css/owl.theme.default.min.css')); ?>>

        <link rel="stylesheet" href=<?php echo e(asset('css/bootstrap.min.css')); ?>>
        <script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
        <script src=<?php echo e(asset('js/owl.carousel.min.js')); ?>></script>

    </head>
    <body class="container-fluid p-0 m-0">
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section>
            <?php echo e($title); ?>

        </section>
        <footer style="min-height: 50vh; background-color: black; color: white" class="p-0 m-0">
            <div class="row">
                <h5>Контакты</h5>
            </div>
        </footer>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\kompany-theme\theme-app\resources\views/order.blade.php ENDPATH**/ ?>