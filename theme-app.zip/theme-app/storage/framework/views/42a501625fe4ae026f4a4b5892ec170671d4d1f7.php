        <section class="p-0 m-0 row col-11 d-flex flex-nowrap justify-content-center" style="min-height: 50vh">
            <div class="col-8 p-0 m-0">
                <div class="owl-carousel owl-theme" data-id="1">
                    <div class="item" id="d1" data-price="25000">
                        <img src="<?php echo e(asset('images/projects/p1/item/ai11.png')); ?> " alt="ai11"  height="112" />
                    </div>
                    <div class="item" id="d1" data-price="25000">
                        <img src="<?php echo e(asset('images/projects/p1/item/ai12.png')); ?> " alt="ai12" height="112"/>
                    </div>
                </div>
                <div class="owl-carousel owl-theme" data-id="2">
                    <div class="item" data-id="1">
                        <div>
                            <img src="<?php echo e(asset('images/projects/p1/item/ai21.png')); ?> " alt="ai21" height="160"/>
                        </div>
                    </div>
                </div>
                <div class="owl-carousel owl-theme" data-id="3">
                    <div class="item">
                        <div>
                            <img src="<?php echo e(asset('images/projects/p1/item/ai31.png')); ?> " alt="ai31" height="160"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-3 p-0 m-0">
                <div>
                    <div class="owl-carousel owl-theme" data-id="4">
                        <div class="item">
                            <div  >
                                <img src="<?php echo e(asset('images/projects/p1/item/ai41.png')); ?> " alt="ai41" height="90" />
                            </div>
                        </div>
                        <div class="item">
                            <div >
                                <img src="<?php echo e(asset('images/projects/p1/item/ai42.png')); ?> " alt="ai42" height="90" />
                            </div>
                        </div>
                        <div class="item">
                            <div >

                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="owl-carousel owl-theme" data-id="5">
                        <div class="item">
                            <div  >
                                <img src="<?php echo e(asset('images/projects/p1/item/ai51.png')); ?> " alt="ai51"  height="339"/>
                            </div>
                        </div>
                        <div class="item">
                            <div>
                                <img src="<?php echo e(asset('images/projects/p1/item/ai52.png')); ?> " alt="ai52" height="339" />
                            </div>
                        </div>
                        <div class="item">
                            <div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="d-flex row justify-content-center m-0 p-0">
            <div class="col-6 p-0 m-0">
                <div class="card d-flex row justify-content-center flex-wrap">
                    <p>Размеры антресолей &nbsp;</p>
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">мм</span>
                        <input type="number" class="form-control" placeholder="Длинна, мм" aria-label="Длинна, мм" aria-describedby="basic-addon1">
                    </div>
                    <p class="info" id="1">0</p>
                </div>
                <div class="card d-flex row justify-content-center col-12">
                    <p>Размеры верхнего модуля</p>
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">мм</span>
                        <input type="number" class="form-control" placeholder="Длинна, мм" aria-label="Длинна, мм" aria-describedby="basic-addon1">
                    </div>
                    <p class="info" id="2">0</p>
                </div>
                <div class="card d-flex row justify-content-center">
                    <p>Размеры нижних модулей</p>
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">мм</span>
                        <input type="number" class="form-control" placeholder="Длинна, мм" aria-label="Длинна, мм" aria-describedby="basic-addon1">
                    </div>
                    <p class="info" id="3">0</p>
                </div>
            </div>
            <div class="col-6 p-0 m-0">
                <div class="card" style="height: 22vh;">
                    <p>Информация 1</p>
                    <p class="info" id="4">0</p>
                </div>
                <div class="card" style="height: 40vh;">
                    <p>Информация 1</p>
                    <p class="info" id="5">0</p>
                </div>
            </div>
        </section>


<?php /**PATH C:\xampp\htdocs\kompany-theme\theme-app\resources\views/calculateMob.blade.php ENDPATH**/ ?>